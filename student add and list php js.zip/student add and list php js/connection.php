<?php

$username = "root";
$password = "root";
$database = "basizfa";

$conn = new mysqli("localhost", $username, $password, $database);

?>